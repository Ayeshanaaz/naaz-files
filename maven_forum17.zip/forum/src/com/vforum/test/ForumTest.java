package com.vforum.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class ForumTest {

	// ForumDao daoTest = new ForumDao();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testRegisterEmployee() {
		fail("Not yet implemented");
	}

	@Test
	public void testCreatePost() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddAnswer() {
		fail("Not yet implemented");
	}

	@Test
	public void testFetchAnswers() {
		fail("Not yet implemented");
	}

	@Test
	public void testFetchPosts() {
		fail("Not yet implemented");
	}

	@Test
	public void testFetchPostAnswers() {
		fail("Not yet implemented");
	}

	@Test
	public void testEditPost() {
		fail("Not yet implemented");
	}

	@Test
	public void testEditAnswer() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchAnswer() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchPosts() {
		fail("Not yet implemented");
	}

	@Test
	public void testDoEmpLoginCheck() {
		fail("Not yet implemented");
	}

	@Test
	public void testDoAdminLoginCheck() {
		fail("Not yet implemented");
	}

	@Test
	public void testFetchPostByDate() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeletePost() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteAnswer() {
		fail("Not yet implemented");
	}

}
