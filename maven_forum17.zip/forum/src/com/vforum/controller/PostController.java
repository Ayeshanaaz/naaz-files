package com.vforum.controller;

import java.io.IOException;

import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.vforum.model.Answer;
import com.vforum.model.Post;
import com.vforum.service.ForumService;
import com.vforum.util.Utils;

/**
 * Servlet implementation class PostController
 */
@WebServlet("/PostController")
public class PostController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public PostController() {
		super();

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Logger logger = Logger.getLogger("PostController");
		response.setContentType("text/html");
		String postId = request.getParameter("currentPostId");
		logger.info("Post id is 500 range?? " + postId);
		ForumService service = new ForumService();
		Post post = Utils.getPostFromId(Utils.parseStringToInt(postId));
		logger.info("Current Post is must be 500 range" + post.toString());
		request.setAttribute("selectedpost", post);
		List<Answer> answerList = service.fetchPostAnswers(post.getPostId());
		request.setAttribute("answers", answerList);
		try {
			request.getRequestDispatcher("/jsp/postdetail.jsp").forward(request, response);
		} catch (Exception e) {
			logger.error(e);
		}
	}

}
