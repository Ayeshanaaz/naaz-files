package com.vforum.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.vforum.model.Employee;
import com.vforum.service.ForumService;
import com.vforum.util.Utils;

/**
 * Servlet implementation class RegisterController
 */
@WebServlet("/RegisterController")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegisterController() {
		super();
		
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		Logger logger = Logger.getLogger("registerController");
		String empName = request.getParameter("EmployeeName");
		int empId = Utils.parseStringToInt(request.getParameter("employee id"));
		String empPassword = request.getParameter("password");
		String empLocation = request.getParameter("customerAddress");
		String empAlias = request.getParameter("customerAlias");
		String empDesignation = request.getParameter("employee des");
		Employee employee = new Employee(empId, empName, empPassword, empLocation, empAlias, empDesignation);
		
		ForumService service = new ForumService();
		RequestDispatcher dispatcher = null;
		
		try {
			int genId = service.registerEmployee(employee);
			
			if (genId != 0) {
				dispatcher = request.getRequestDispatcher("/html/home.html");
			} else {
				dispatcher = request.getRequestDispatcher("/html/registration.html");
			}
			
		} catch (Exception e) {
			logger.error(e);
			dispatcher = request.getRequestDispatcher("/html/error.html");
		}
		try {
			dispatcher.forward(request, response);
		} catch (Exception e) {
			logger.error(e);
		}
		
	}
	
}
