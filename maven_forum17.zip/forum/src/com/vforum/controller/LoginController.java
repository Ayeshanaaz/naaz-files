package com.vforum.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.vforum.model.Employee;
import com.vforum.service.ForumService;
import com.vforum.util.Utils;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginController() {
		super();

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Logger logger = Logger.getLogger("LoginController");
		response.setContentType("text/html");
		ForumService service = new ForumService();
		int empId = Utils.parseStringToInt(request.getParameter("emp_id").trim());
		String password = request.getParameter("password");
		Employee edetail = Utils.getEmployeeFromId(empId);
		try {
			int flag = service.doEmpLoginCheck(empId, password);
			if (flag == 0) {
				logger.info("Login Not Sucesfull <<<<<<<<<< By User" + edetail.toString());
				request.setAttribute("message", "Are you sure with your password? | Retry");
				RequestDispatcher dispatcher = request.getRequestDispatcher("/jsp/login.jsp");
				dispatcher.forward(request, response);
			} else {
				HttpSession session = request.getSession();
				session.setAttribute("empId", edetail.getEmpId());
				session.setAttribute("user_name", edetail.getEmpName());
				session.setAttribute("emp", edetail);
				request.setAttribute("message","Login Sucessful");
				logger.info("Login Sucesfull <<<<<<<<<< By User" + edetail.toString());
				RequestDispatcher dispatcher = request.getRequestDispatcher("/HomeController");
				dispatcher.forward(request, response);
			}

		} catch (Exception e) {
			logger.error(e);
			request.setAttribute("message", "Some Internal Error Occured Contact Admin");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/jsp/login.jsp");
			try {
				dispatcher.forward(request, response);
			} catch (Exception e1) {
				logger.error(e1);
			}
		}
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

}
