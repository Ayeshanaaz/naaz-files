package com.vforum.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.vforum.model.Employee;
import com.vforum.service.ForumService;
import com.vforum.util.Utils;

/**
 * Servlet implementation class SignUpController
 */
@WebServlet("/SignUpController")
public class SignUpController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final int INTEGRITYCONSTANT = 555;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SignUpController() {
		super();

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Logger logger = Logger.getLogger("SignUpController");
		String empName = request.getParameter("EmployeeName");
		int empId = Utils.parseStringToInt(request.getParameter("employee id").trim());
		String empPassword = request.getParameter("password");
		String empLocation = request.getParameter("customerAddress");
		String empAlias = request.getParameter("customerAlias");
		String empDesignation = request.getParameter("employee des");
		response.setContentType("text/html");
		Employee employee = new Employee(empId, empName, empAlias, empDesignation, empLocation, empPassword);
		ForumService service = new ForumService();
		RequestDispatcher dispatcher = null;
		try {
			int genId = service.registerEmployee(employee);
			if (genId == 1) {
				request.setAttribute("message", "Employee Registered");
				dispatcher = request.getRequestDispatcher("/HomeController");
			} else if (genId == INTEGRITYCONSTANT) {
				request.setAttribute("message", "Oops! Employee Id Already Exists. Try Logging in");
				dispatcher = request.getRequestDispatcher("/jsp/signup.jsp");
			} else {
				dispatcher = request.getRequestDispatcher("/jsp/signup.jsp");
			}
		} catch (Exception e) {
			dispatcher = request.getRequestDispatcher("/html/error.html");
			logger.error("err page", e);
		}
		try {
			dispatcher.forward(request, response);
		} catch (Exception e) {
			logger.error(e);
		}

	}

}
