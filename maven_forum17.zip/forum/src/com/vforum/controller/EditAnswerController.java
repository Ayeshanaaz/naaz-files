package com.vforum.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.vforum.model.Answer;
import com.vforum.util.Utils;

/**
 * Servlet implementation class EditAnswerController
 */
@WebServlet("/EditAnswerController")
public class EditAnswerController extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger("EditAnswerController");
	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EditAnswerController() {
		super();
		
	}
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		int answerId = Utils.parseStringToInt(request.getParameter("editAnswer"));
		Answer answer = Utils.getAnswerFromId(answerId);
		request.setAttribute("currentAnswer", answer);
		logger.info(answer.toString());
		RequestDispatcher dispatcher = request.getRequestDispatcher("jsp/editAnswer.jsp");
		try {
			dispatcher.forward(request, response);
		} catch (Exception e) {
			logger.error(e);
		}
	}
	
}
