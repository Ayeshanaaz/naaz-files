package com.vforum.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.vforum.model.Answer;

import com.vforum.service.ForumService;
import com.vforum.util.Utils;

/**
 * Servlet implementation class UpdateAnswerController
 */
@WebServlet("/UpdateAnswerController")
public class UpdateAnswerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateAnswerController() {
		super();
		
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Logger logger = Logger.getLogger("UpdateAnswer");
		response.setContentType("text/html");
		String postdesc = request.getParameter("answerdesc");
		int answerId = Utils.parseStringToInt(request.getParameter("currentanswerId"));
		Answer answer = new Answer(postdesc);
		logger.info("This is in UpdateAnswerController <<<<<<<<<<<<<<<" + answer.toString() + " || " + answerId);
		ForumService service = new ForumService();
		service.editAnswer(answer, answerId);
		logger.info(answer.toString());
		request.setAttribute("message", "Answer Edited");
		RequestDispatcher dispatcher = request.getRequestDispatcher("/HomeController");
		try {
			dispatcher.forward(request, response);
		} catch (Exception e) {
			logger.error(e);
		}
	}
	
}
