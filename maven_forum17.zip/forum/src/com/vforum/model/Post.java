package com.vforum.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "posttab")
public class Post {

	public Post() {
		super();
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int postId;
	private String postDesc;
	private Date postDate;
	// private int empId;
	@ManyToOne
	@JoinColumn(name = "empId")
	private Employee employeeP;
	@OneToMany(mappedBy = "postA", orphanRemoval = true, cascade = CascadeType.ALL)
	private List<Answer> answers;

	public List<Answer> getAnswers() {
		return answers;
	}

	public void setAnswers(List<Answer> answers) {
		this.answers = answers;
	}

	public Post(String postDesc, Employee employee) {
		super();
		this.postDesc = postDesc;
		this.employeeP = employee;
	}

	public Post(int postId, String postDesc, Date postDate, int empId) {
		super();
		this.postId = postId;
		this.postDesc = postDesc;
		this.postDate = (Date) postDate.clone();
		// this.empId = empId;
	}

	public Post(String postDesc, Date postDate, Employee employee) {
		super();
		this.postDesc = postDesc;
		this.postDate = postDate;
		this.employeeP = employee;
	}

	public Employee getEmployee() {
		return employeeP;
	}

	public void setEmployee(Employee employee) {
		this.employeeP = employee;
	}

	public Post(String postDesc2) {
		this.postDesc = postDesc2;
	}

	public Post(int postId, String postDesc, int empId) {
		super();
		this.postId = postId;
		this.postDesc = postDesc;
		// this.empId = empId;
	}

	public void setPostsId(int postsId) {
		this.postId = postsId;
	}

	public String getPostDesc() {
		return postDesc;
	}

	public void setPostDesc(String postDesc) {
		this.postDesc = postDesc;
	}

	public Date getPostDate() {
		return new Date(postDate.getTime());
	}

	public void setPostDate(Date postDate) {
		this.postDate = (Date) postDate.clone();
	}

	public Employee getPostEmpId() {
		return null;
	}

	public int getPostId() {
		return postId;
	}

	public void setPostId(int postId) {
		this.postId = postId;
	}

	@Override
	public String toString() {
		return "\n\nPost [postId=" + postId + ", postDesc=" + postDesc + ", employeeP=" + employeeP.getEmpId()
				+ "]\n\n";
	}

	// public Employee getEmployeeObj() {
	// return Utils.getEmployeeFromId(empId);
	// }
	//
	// public int getEmpId() {
	// return empId;
	// }
	//
	// public void setEmpId(int empId) {
	// this.empId = empId;
	// }

}
