package com.vforum.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.vforum.util.Utils;

@Entity
@Table(name = "answertab")
public class Answer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int answerId;

	public Answer(String answerDesc, Employee employee) {
		super();
		this.answerDesc = answerDesc;
		this.employeeA = employee;
	}

	public Answer() {
		super();
	}

	private String answerDesc;
	private Date answerDate;
	// private Post answerPostObj;
	// private int employeeId;
	// private int postId;

	@ManyToOne
	@JoinColumn(name = "empId")
	private Employee employeeA;
	@ManyToOne
	@JoinColumn(name = "postId")
	private Post postA;

	public Employee getEmployeeA() {
		return employeeA;
	}

	public void setEmployeeA(Employee employeeA) {
		this.employeeA = employeeA;
	}

	public Post getPostA() {
		return postA;
	}

	public void setPostA(Post postA) {
		this.postA = postA;
	}

	public Answer(String answerDesc, Employee employeeA, Post postA) {
		super();
		this.answerDesc = answerDesc;
		this.employeeA = employeeA;
		this.postA = postA;
	}

	public Answer(int answerId, String answerDesc, Date answerDate, int employeeId, int postId) {
		super();
		this.answerId = answerId;
		this.answerDesc = answerDesc;
		this.answerDate = (Date) answerDate.clone();
		// this.postId = postId;
		// this.employeeId = employeeId;
	}

	public Answer(String answerDesc) {
		super();
		this.answerDesc = answerDesc;
	}

	// public Post getAnswerPostId() {
	// return answerPostObj;
	// }
	//
	// // public Employee getAnswerEmpObj() {
	// // return Utils.getEmployeeFromId((int) employeeId);
	// // }
	//
	// public void setAnswerPostId(Post answerPostId) {
	// this.answerPostObj = answerPostId;
	// }
	//
	// public int getEmployeeId() {
	// return employeeId;
	// }
	//
	// public void setEmployeeId(int employeeId) {
	// this.employeeId = employeeId;
	// }
	//
	// public int getPostId() {
	// return postId;
	// }
	//
	// public void setPostId(int postId) {
	// this.postId = postId;
	// }

	public int getAnswerId() {
		return answerId;
	}

	public void setAnswerId(int answerId) {
		this.answerId = answerId;
	}

	public String getAnswerDesc() {
		return answerDesc;
	}

	public void setAnswerDesc(String answerDesc) {
		this.answerDesc = answerDesc;
	}

	public Date getAnswerDate() {
		return (Date) answerDate.clone();
	}

	public void setAnswerDate(Date answerDate) {
		this.answerDate = (Date) answerDate.clone();
	}

	@Override
	public String toString() {
		return "\n\nAnswer [answerId=" + answerId + ", answerDesc=" + answerDesc + ", employeeA=" + employeeA.getEmpId()
				+ ", postA=" + postA.getPostId() + "]\n\n";
	}

}
