/*
 * Owned by Owner
 */

package com.vforum.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.vforum.model.Admin;
import com.vforum.model.Answer;
import com.vforum.model.Employee;
import com.vforum.model.Post;
import com.vforum.util.ConnectionUtil;
import com.vforum.util.Utils;

public class ForumDao {

	private static Session session;

	private static void setupHibernate() {
		final Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		// System.out.println(configuration.getProperty("hibernate.connection.url"));
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session sessiontemp = sessionFactory.openSession();
		session = sessiontemp;
	}

	private static final int ONE = 1;
	private static final int TWO = 2;
	private static final int THREE = 3;
	private static final int FOUR = 4;
	private static final int FIVE = 5;
	private static final int SIX = 6;

	public int registerAdmin(Admin admin) {
		final Logger logger = Logger.getLogger("RegisterAdminDao");
		setupHibernate();
		Transaction transaction = session.beginTransaction();
		session.saveOrUpdate(admin);
		if (session.contains(admin)) {
			transaction.commit();
			session.close();
			return 1;
		} else {
			transaction.commit();
			session.close();
			return 0;
		}
		/*Connection connection = ConnectionUtil.getConnection();
		int ret = 0;
		try (PreparedStatement stmt = connection.prepareStatement(
				"INSERT INTO `admin` (admin_uname,admin_password) VALUES ( ? , ? )", Statement.RETURN_GENERATED_KEYS)) {
			stmt.setString(ONE, admin.getAdminUname());
			stmt.setString(TWO, admin.getAdminPassword());
			stmt.executeUpdate();
			try (ResultSet rs = stmt.getGeneratedKeys()) {
				if (rs.next()) {
					ret = Integer.parseInt(rs.getString(ONE));
				}
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return ret;*/
	}

	public int registerEmployee(Employee employee) {
		setupHibernate();
		Transaction transaction = session.beginTransaction();
		session.saveOrUpdate(employee);
		if (session.contains(employee)) {
			transaction.commit();
			session.close();
			return 1;
		} else {
			transaction.commit();
			session.close();
			return 0;
		}

		// final int INTEGRITYERRVAL = 555;
		// Logger logger = Logger.getLogger("RegisterEmployeeDao");
		// Connection connection = ConnectionUtil.getConnection();
		// int ret = 0;
		// try (PreparedStatement stmt = connection.prepareStatement("INSERT
		// INTO `employee` VALUES (?,?,?,?,?,?)",
		// PreparedStatement.RETURN_GENERATED_KEYS)) {
		// stmt.setInt(ONE, employee.getEmpId());
		// stmt.setString(TWO, employee.getEmpName());
		// stmt.setString(THREE, employee.getEmpAlias());
		// stmt.setString(FOUR, employee.getEmpDesignation());
		// stmt.setString(FIVE, employee.getEmpLocation());
		// stmt.setString(SIX, employee.getEmpPassword());
		// stmt.executeUpdate();
		// ret = 1;
		// } catch (SQLException e) {
		// logger.error(e);
		// ret = INTEGRITYERRVAL;
		// logger.warn("Integerity Constraint
		// <|||||||||||||||||||||||||||||||||||" + e.getStackTrace());
		// }
		// return ret;
	}

	public int createPost(Post post, int empId) {
		
		//	Logger logger = Logger.getLogger("PostDao");
		setupHibernate();
		Transaction transaction = session.beginTransaction();
		
		Employee e=session.get(Employee.class, empId);
		String postDesc=post.getPostDesc();
		Post p1=new Post(postDesc, e);
		session.saveOrUpdate(p1);
		if (session.contains(p1)) {
			transaction.commit();
			session.close();
			return 1;
		} else {
			transaction.commit();
			session.close();
			return 0;
		}
		/*Connection connection = ConnectionUtil.getConnection();
		int ret = 0;
		try (PreparedStatement stmt = connection.prepareStatement(
				"INSERT INTO post (`post_desc`,`post_date`,`post_emp_id`) VALUES(?,?,?)",
				Statement.RETURN_GENERATED_KEYS)) {
			stmt.setString(ONE, post.getPostDesc());
			stmt.setString(TWO, Utils.getCurrentDateTime());
			stmt.setInt(THREE, empId);
			stmt.executeUpdate();
			try (ResultSet rs = stmt.getGeneratedKeys()) {
				if (rs.next()) {
					ret = Integer.parseInt(rs.getString(ONE));
				}
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return ret;*/
	}

	public int addAnswer(Answer answer, int postId, int empId) {
		Logger logger = Logger.getLogger("AnswerDao");
		Connection connection = ConnectionUtil.getConnection();
		int ret = 0;
		try (PreparedStatement stmt = connection.prepareStatement(
				"INSERT INTO answer (`answer_desc`,`answer_date`,`answer_emp_id`,`answer_post_id`) VALUES(?,?,?,?)",
				Statement.RETURN_GENERATED_KEYS)) {
			stmt.setString(ONE, answer.getAnswerDesc());
			stmt.setString(TWO, Utils.getCurrentDateTime());
			stmt.setInt(THREE, empId);
			stmt.setInt(FOUR, postId);
			stmt.executeUpdate();
			try (ResultSet rs = stmt.getGeneratedKeys()) {
				if (rs.next()) {
					ret = Integer.parseInt(rs.getString(ONE));
				}
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return ret;
	}

	public List<Answer> fetchAnswers(int empId) {
		Logger logger = Logger.getLogger("FetchAnswerDao");
		Connection connection = ConnectionUtil.getConnection();
		ArrayList<Answer> answerLists = new ArrayList<>();
		try (PreparedStatement stmt = connection
				.prepareStatement("select * from answer where answer_emp_id = ? order by answer_date desc")) {
			stmt.setInt(ONE, empId);
			try (ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					answerLists.add(new Answer(rs.getInt(ONE), rs.getString(TWO),
							new Date(rs.getTimestamp(THREE).getTime()), rs.getInt(FOUR), rs.getInt(FIVE)));
				}
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return answerLists;
	}

	public List<Post> fetchPosts(int empId) {
		Logger logger = Logger.getLogger("FetchPostDao");
		Connection connection = ConnectionUtil.getConnection();
		ArrayList<Post> postLists = new ArrayList<>();
		try (PreparedStatement stmt = connection
				.prepareStatement("select * from post where post_emp_id = ? order by post_date desc")) {
			stmt.setInt(ONE, empId);
			try (ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					postLists.add(new Post(rs.getInt(ONE), rs.getString(TWO),
							new Date(rs.getTimestamp(THREE).getTime()), rs.getInt(FOUR)));
				}
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return postLists;
	}

	public List<Answer> fetchPostAnswers(int postId) {
		Logger logger = Logger.getLogger("FetchPostAnswerDao");
		Connection connection = ConnectionUtil.getConnection();
		ArrayList<Answer> answerLists = new ArrayList<>();
		try (PreparedStatement stmt = connection
				.prepareStatement("select * from answer where answer_post_id = ? order by answer_date desc")) {
			stmt.setInt(ONE, postId);

			try (ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					answerLists.add(new Answer(rs.getInt(ONE), rs.getString(TWO),
							new Date(rs.getTimestamp(THREE).getTime()), rs.getInt(FOUR), rs.getInt(FIVE)));
				}
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return answerLists;

	}

	public int editPost(Post post, int postId) {
		Logger logger = Logger.getLogger("EditPostDao");
		Connection connection = ConnectionUtil.getConnection();
		int ret = 0;
		try (PreparedStatement stmt = connection.prepareStatement("update post set post_desc = ? WHERE post_id = ?",
				Statement.RETURN_GENERATED_KEYS)) {
			stmt.setString(ONE, post.getPostDesc());
			stmt.setInt(TWO, postId);
			stmt.executeUpdate();
			try (ResultSet rs = stmt.getGeneratedKeys()) {
				if (rs.next()) {
					ret = Integer.parseInt(rs.getString(ONE));
				}
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return ret;
	}

	public int editAnswer(Answer answer, int answerId) {
		Logger logger = Logger.getLogger("EditAnswerDao");
		Connection connection = ConnectionUtil.getConnection();
		int ret = 0;
		try (PreparedStatement stmt = connection.prepareStatement(
				"update answer set answer_desc = ? WHERE answer_id = ?", Statement.RETURN_GENERATED_KEYS)) {
			stmt.setString(ONE, answer.getAnswerDesc());
			stmt.setInt(TWO, answerId);
			stmt.executeUpdate();
			try (ResultSet rs = stmt.getGeneratedKeys()) {
				if (rs.next()) {
					ret = Integer.parseInt(rs.getString(ONE));
				}
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return ret;
	}

	public List<Answer> searchAnswer(String searchQuery) {
		Logger logger = Logger.getLogger("SearchAnswerDao");
		Connection connection = ConnectionUtil.getConnection();
		ArrayList<Answer> answerLists = new ArrayList<>();
		try (PreparedStatement stmt = connection.prepareStatement(
				"select * from answer where MATCH (answer_desc) AGAINST(?) order by answer_date desc")) {
			stmt.setString(ONE, searchQuery);
			try (ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					answerLists.add(new Answer(rs.getInt(ONE), rs.getString(TWO),
							new Date(rs.getTimestamp(THREE).getTime()), rs.getInt(FOUR), rs.getInt(FIVE)));
				}
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return answerLists;
	}

	public List<Post> searchPosts(String searchQuery) {
		Logger logger = Logger.getLogger("SearchPostDao");
		Connection connection = ConnectionUtil.getConnection();
		ArrayList<Post> postLists = new ArrayList<>();
		logger.info("Search Query Recieved || " + searchQuery);

		try (PreparedStatement stmt = connection
				.prepareStatement("select * from post where MATCH (post_desc) AGAINST(?) order by post_date desc")) {
			stmt.setString(ONE, searchQuery);
			try (ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					postLists.add(new Post(rs.getInt(ONE), rs.getString(TWO),
							new Date(rs.getTimestamp(THREE).getTime()), rs.getInt(FOUR)));
				}
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		logger.info("Result Set Recieved with Size || " + postLists.size());
		return postLists;
	}

	public int doEmpLoginCheck(int empId, String password) {
		Logger logger = Logger.getLogger("EmpLoginDao");
		logger.info("DaoCheck Emp id nd password " + empId + "  ...  " + password);
		Connection connection = ConnectionUtil.getConnection();
		int flag = 0;
		try (PreparedStatement stmt = connection
				.prepareStatement("select * from employee where emp_id = ? AND emp_password = ?")) {
			stmt.setInt(ONE, empId);
			stmt.setString(TWO, password);
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					flag = 1;
				} else {
					flag = 0;
				}
			}
		} catch (SQLException e) {

			logger.error(e);
		}
		return flag;
	}

	public int doAdminLoginCheck(int adminId, String password) {
		Logger logger = Logger.getLogger("AdminLoginDao");
		Connection connection = ConnectionUtil.getConnection();
		int flag = 0;
		try (PreparedStatement stmt = connection
				.prepareStatement("select * from admin where admin_id = ? AND admin_password = ?")) {
			stmt.setInt(ONE, adminId);
			stmt.setString(TWO, password);
			logger.info("AdminLoginCheck <<<<<<<<<<>>>>>>>>>>>>" + adminId + password);
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					flag = 1;
					logger.info(rs.toString());
				} else {
					flag = 0;
				}
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return flag;
	}

	public List<Post> fetchPostByDate() {
		Logger logger = Logger.getLogger("FetchPostDao");
		Connection connection = ConnectionUtil.getConnection();
		System.out.println("Why is my connection object null >>>>>>>>>>> " + connection + "\n\n");
		ArrayList<Post> postLists = new ArrayList<>();
		try (PreparedStatement stmt = connection.prepareStatement("select * from post order by post_date desc")) {
			try (ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					postLists.add(new Post(rs.getInt(ONE), rs.getString(TWO),
							new Date(rs.getTimestamp(THREE).getTime()), rs.getInt(FOUR)));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e);
		}
		return postLists;
	}

	public int deletePost(int postId) {
		Logger logger = Logger.getLogger("DeletePostDao");
		Connection connection = ConnectionUtil.getConnection();
		int ret = 0;
		// PreparedStatement stmt=null;
		try (PreparedStatement stmt = connection.prepareStatement("delete from post where post_id = ?",
				Statement.RETURN_GENERATED_KEYS)) {
			stmt.setInt(ONE, postId);
			stmt.executeUpdate();
			try (ResultSet rs = stmt.getGeneratedKeys()) {
				if (rs.next()) {
					ret = Integer.parseInt(rs.getString(ONE));
				}
			}
		} catch (SQLException e) {

			logger.error(e);
		}
		return ret;
	}

	public int deleteAnswer(int answerId) {
		Logger logger = Logger.getLogger("DeleteAnswerDao");
		Connection connection = ConnectionUtil.getConnection();
		int ret = 0;
		try (PreparedStatement stmt = connection.prepareStatement("delete from answer where answer_id = ?",
				Statement.RETURN_GENERATED_KEYS)) {
			stmt.setInt(ONE, answerId);
			stmt.executeUpdate();
			try (ResultSet rs = stmt.getGeneratedKeys()) {
				if (rs.next()) {
					ret = Integer.parseInt(rs.getString(ONE));
				}
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return ret;
	}
}
