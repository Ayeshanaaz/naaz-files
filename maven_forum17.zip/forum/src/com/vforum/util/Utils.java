package com.vforum.util;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.vforum.model.Admin;
import com.vforum.model.Answer;
import com.vforum.model.Employee;
import com.vforum.model.Post;

public final class Utils {

	private static final int ONE = 1;
	private static final int TWO = 2;
	private static final int THREE = 3;
	private static final int FOUR = 4;
	private static final int FIVE = 5;
	private static final int SIX = 6;

	private static final Logger LOGGER = Logger.getLogger("DeleteAnswerController");

	private Utils() {

	}

	public static String getCurrentDateTime() {
		java.util.Date dt = new java.util.Date();
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(dt);
	}

	public static Integer parseStringToInt(String number) {
		Integer returnVal = 0;
		try {
			returnVal = Integer.parseInt(number.trim());
		} catch (NumberFormatException e) {
			LOGGER.error(e);
		}
		return returnVal;
	}

	public static Employee getEmployeeFromId(int empId) {
		Employee employee = null;
		Connection connection = ConnectionUtil.getConnection();
		try (PreparedStatement stmt = connection.prepareStatement("select * from employee where emp_id = ?")) {
			stmt.setInt(1, empId);
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					employee = new Employee(rs.getInt(ONE), rs.getString(TWO), rs.getString(THREE), rs.getString(FOUR),
							rs.getString(FIVE), rs.getString(SIX));
				} else {
					LOGGER.error("Employee not Present for the specified empId");
				}
			}

		} catch (SQLException e) {
			LOGGER.error(e);
		}
		return employee;
	}

	public static Admin getAdminFromId(int adminId) {
		Admin admin = null;
		Connection connection = ConnectionUtil.getConnection();

		try (PreparedStatement stmt = connection.prepareStatement("select * from admin where admin_id = ?")) {
			stmt.setInt(1, adminId);
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					admin = new Admin(rs.getInt(ONE), rs.getString(TWO), rs.getString(THREE));
				} else {
					LOGGER.error("Admin not present with the specified Id");
				}
			}
		} catch (SQLException e) {
			LOGGER.error(e);
		}
		return admin;
	}

	public static Post getPostFromId(int postId) {
		Post post = null;
		Connection connection = ConnectionUtil.getConnection();
		try (PreparedStatement stmt = connection.prepareStatement("select * from post where post_id = ?")) {
			stmt.setInt(1, postId);
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					post = new Post(rs.getInt(ONE), rs.getString(TWO), new Date(rs.getTimestamp(THREE).getTime()),
							rs.getInt(FOUR));
				}
			}
		} catch (SQLException e) {
			LOGGER.error(e);
		}
		return post;

	}

	public static Answer getAnswerFromId(int answerId) {
		Answer answer = null;
		Connection connection = ConnectionUtil.getConnection();
		try (PreparedStatement stmt = connection.prepareStatement("select * from answer where answer_id = ?")) {
			stmt.setInt(1, answerId);
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					answer = new Answer(rs.getInt(ONE), rs.getString(TWO), new Date(rs.getTimestamp(THREE).getTime()),
							rs.getInt(FOUR), rs.getInt(FIVE));
				}
			}
		} catch (SQLException e) {
			LOGGER.error(e);
		}
		return answer;

	}

	public static List<Post> fetchPostByDate() {
		Logger logger = Logger.getLogger("FetchPostByDate");
		Connection connection = ConnectionUtil.getConnection();
		ArrayList<Post> postLists = new ArrayList<>();
		try (PreparedStatement stmt = connection.prepareStatement("select * from post order by post_date desc")) {
			try (ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					postLists.add(new Post(rs.getInt(ONE), rs.getString(TWO),
							new Date(rs.getTimestamp(THREE).getTime()), rs.getInt(FOUR)));
				}
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return postLists;
	}

}
